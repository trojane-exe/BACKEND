package org.example.ecomercewebapp.Model;

public enum RoleEnum {

    Admin,
    User
}
