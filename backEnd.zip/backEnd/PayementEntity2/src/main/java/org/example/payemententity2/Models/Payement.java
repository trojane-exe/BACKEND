package org.example.payemententity2.Models;


import jakarta.persistence.*;
import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Entity
@Getter
@Setter
public class Payement {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name = "factureId")
    private Integer factureId ;

    private Integer userId;

    private Integer cartId;

    private Float total;

    @Enumerated(EnumType.STRING)
    private EtatEnum status;

}
