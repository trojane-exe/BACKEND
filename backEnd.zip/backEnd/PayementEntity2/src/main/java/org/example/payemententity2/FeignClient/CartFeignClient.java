package org.example.payemententity2.FeignClient;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "cart-service", url = "localhost:8082/api/carts")
public interface CartFeignClient {


    @DeleteMapping("/cancelCart")
    void cancelCart(@RequestParam("userId")Integer userId);
}
