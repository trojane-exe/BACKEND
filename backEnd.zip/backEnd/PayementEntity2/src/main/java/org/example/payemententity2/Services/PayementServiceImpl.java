package org.example.payemententity2.Services;

import jakarta.transaction.Transactional;
import org.example.payemententity2.FeignClient.CartFeignClient;
import org.example.payemententity2.Models.EtatEnum;
import org.example.payemententity2.Models.Payement;
import org.example.payemententity2.Repositories.PayementRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Transactional

public class PayementServiceImpl implements PayementService{


    private final PayementRepository payementRepository;
    private final CartFeignClient cartFeignClient;

    @Autowired
    public PayementServiceImpl(PayementRepository payementRepository,CartFeignClient cartFeignClient) {
        this.payementRepository = payementRepository;
        this.cartFeignClient=cartFeignClient;

    }

    @Override
    public String proceedToPayement(Payement payement) {
        if(payement !=null){

            payement.setStatus(EtatEnum.Pending);
            payementRepository.save(payement);
            return "ok";
        }
        else {
            return "error";
        }
    }

    @Override
    public String validatePayement(Integer id) {
        Payement payement = payementRepository.findById(id).orElse(null);
        if(payement!=null){
            payement.setStatus(EtatEnum.Payed);
            payementRepository.save(payement);
            cartFeignClient.cancelCart(payement.getUserId());

        }
        return null;
    }

    @Override
    public List<Payement> listOfFactures(Integer userID) {
        return payementRepository.getAllByUserId(userID);
    }

    @Override
    public Integer lastId(Integer id) {
        return payementRepository.getId(id);
    }
}
