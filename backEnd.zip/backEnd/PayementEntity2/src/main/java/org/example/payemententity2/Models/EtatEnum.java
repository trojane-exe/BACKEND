package org.example.payemententity2.Models;

public enum EtatEnum {

    Payed,
    Pending
}
