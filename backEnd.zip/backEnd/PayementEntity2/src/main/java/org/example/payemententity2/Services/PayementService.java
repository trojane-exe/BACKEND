package org.example.payemententity2.Services;

import org.example.payemententity2.Models.Payement;

import java.util.List;

public interface PayementService {

    public String proceedToPayement(Payement payement);
    public String validatePayement(Integer id);
    public List<Payement> listOfFactures(Integer userId);
    public Integer lastId(Integer id);
}
