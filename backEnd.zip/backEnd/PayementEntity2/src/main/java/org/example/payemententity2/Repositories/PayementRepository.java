package org.example.payemententity2.Repositories;

import org.example.payemententity2.Models.Payement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface PayementRepository extends JpaRepository<Payement,Integer> {

    @Query("select p from Payement p where p.userId =:userId")
    public List<Payement> getAllByUserId(@Param("userId")Integer userId);


    @Query("select  p.factureId from Payement p where p.userId =:userId order by p.factureId desc limit 1")
    public Integer getId(@Param("userId")Integer userId);


}
