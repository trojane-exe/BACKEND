package org.example.cartentity.Model;

public enum StatusEnum {

    Active,
    Complete,
    Empty,

}
