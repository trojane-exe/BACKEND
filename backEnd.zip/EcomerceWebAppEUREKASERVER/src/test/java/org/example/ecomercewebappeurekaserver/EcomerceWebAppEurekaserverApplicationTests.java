package org.example.ecomercewebappeurekaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcomerceWebAppEurekaserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
